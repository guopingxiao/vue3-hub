


Vue3快
1. proxy 取代Object.defineProperty
2. vdom的静态标记