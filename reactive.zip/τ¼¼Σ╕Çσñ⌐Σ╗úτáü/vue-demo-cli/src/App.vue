<template>
  <div id="app">
    <h1>开课吧 {{top}}</h1>  
    <input :class="{fixeditem:top>200}" type="text" v-model="newTodo" @keyup.enter="addTodo"> 
    <button @click="addTodo">添加</button>
    <ul>
      <li class="todo-item" @click="toggle(index)" :class="{done:todo.completed}" v-for="(todo,index) in todos" :key="todo.id">{{todo.title}}</li>
    </ul> 
    <div>
      {{remaining}}
    </div>
  </div>
</template>

<script>
// {
//   methods:{},
//   data(){},
//   computed:{}
// }
// 如果部import 打包可以把代码丢掉 所谓的tree-shaking
import {ref, reactive,toRefs, computed} from 'vue'
// composition最牛逼的，就是可以拆开成独立的函数 ，放在别的文件
// vue2只能用mixin，但是mixin会找不到源头 也会又重名bug
import useAddTodo from './addTodo'
import useScroll from './useScroll'
// 拆分复杂的逻辑
export default {
  setup(){
    const state = reactive({
      newTodo:'',
      todos:[
        {id:"1",title:"吃饭",completed:true},
        {id:"2",title:"打王者",completed:false},
        {id:"3",title:"写代码",completed:false},
        {id:"4",title:"写代码",completed:false},
        {id:"5",title:"写代码",completed:false},
        {id:"6",title:"写代码",completed:false},
        {id:"7",title:"写代码",completed:false},
      ]
    })
    const remaining = computed(
      ()=>  state.todos.filter(todo=> !todo.completed).length
    )
    function toggle(i){
      state.todos[i].completed = !state.todos[i].completed
    }
    // 任何数据的来源，都很清晰 mixin做不到的
    const {addTodo} = useAddTodo(state)
    const {top} = useScroll()
    return {...toRefs(state),addTodo,remaining,toggle,top}
  }
}
</script>

<style>
li.done{
  text-decoration: line-through;
}
.todo-item{
  height:300px;
  
}
input.fixeditem{
  position: fixed;
  top:0;
  left:0;
}
</style>
