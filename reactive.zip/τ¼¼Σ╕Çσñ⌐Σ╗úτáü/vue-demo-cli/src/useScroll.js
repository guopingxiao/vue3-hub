import {ref, onMounted, onUnmounted} from 'vue'

// 独立的功能，返回滚动高度
export default function useScroll(){
  const top = ref(0)
  function update(e){
    console.log('update')
    top.value = window.scrollY
  }
  // 防抖节流
  onMounted(()=>{
    // 生命周期
    window.addEventListener('scroll', update)
  })
  onUnmounted(()=>{
    window.removeEventListener('scroll', update)
  })
  return {top}
}