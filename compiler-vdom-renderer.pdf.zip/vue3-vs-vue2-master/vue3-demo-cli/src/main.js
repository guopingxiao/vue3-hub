

import {createApp} from 'vue'
import App from './App.vue'
let vm = createApp(App)
vm.mount('#app')

