// import { createApp } from './three-renderer';
// import App from "./App.vue";

import { createApp } from './renderer';
import App from "./App1.vue";
createApp(App).mount("#app")


