import { createApp } from '@vue/runtime-dom';
//import { createApp } from './ThreeRender';

import App from "./App.vue";

//import "./vanilla-main";

createApp(App).mount(document.querySelector("#app"))
