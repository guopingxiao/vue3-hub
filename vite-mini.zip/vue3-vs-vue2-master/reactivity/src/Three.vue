<template>
    <div>
      abc
    </div>
</template>
<script>

export default {
  data: () => ({
    remoteData:{a:1}
  })
}

</script>