import Vue from 'vue'
import App from './App.vue'

let vm = new Vue({
  render: h => h(App),
}).$mount('#app')

